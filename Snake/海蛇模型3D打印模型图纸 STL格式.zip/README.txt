                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2744865
Sea Serpent by 7Fish is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

Sea serpent 

this is developed to study Articulated tail design for dragons and snake tails as well improve ball joint's design and it's hold tension strength from rip offed from it's soket.









# Print Settings

Rafts: Doesn't Matter
Supports: Yes
Resolution: 0.2
Infill: 10%

Notes: 
1) Please be careful not be confused between sets and parts, part number is not ingraved.

2) Body Segments without prebuilt supports are in Zip File. Please Don't chagne oriented Direction to vertically, it reasons are to protect the ball from strain under the soket and scales that may can broken off

3) Assemble Tail tip 02 (Flat tail fin) will need glue to put together

4) if you have trouble the Ball into soket, grind or shave ball's top and bottom about 1mm and try again.

# How I Designed This

This snake is consist of Head(Jaw, Tung, Eye)  and body (climb up scale by 103% each which Tail set 20~21 and Climb down by scale 98% each which Tail set 22~31 and Tail Tip.