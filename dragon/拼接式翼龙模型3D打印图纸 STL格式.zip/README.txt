                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2756952
Wym by 7Fish is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

This is developed to study foldable wing structure for dragon.

It is small and 'Extremely difficult' to make as well it's experimental wing. due to it's small size, some of joints are easy to pop out from soket. 
try at your risk, Recommened to Scale up from 120% to 200% and build part by part than print entrie set although it's providede to minimize the risk.

it's inpired by beautiful Dragonology by Mag-net  (https://www.thingiverse.com/thing:2671240)
and mostly take reference from Skyrim dragons.
articulation design trait was  inherited  from my other two dragons.



march 13, 2018 // Enter revise to insert Ball - Soket Tolerance. re-sizing


# Print Settings

Rafts: Yes
Supports: Doesn't Matter
Resolution: 0.15~2
Infill: 10

Notes: 
SET 01
SET 02 : Tails

Wing Cutting Frame 3: fourth try of wing system
No Brim, raft, 20 infiil, No filling at bottom and top. Put lowst cost setting as possible, once you make cutted wing fabric, it will become useless.

Other parts are mostly for repair and to build it one by one.

Neck and Tails did not have engraved part numbers. please careful not to be confused.

Wing cutting frame 3

Wing 001 (Y mirror)
Wing 002 (Y mirror)
Wing 003 (Y mirror)
Wing hand (Y mirror)

Wing Limb A the longest wing limb
Wing Limb B middle wing limb
Wing Limb C shortest wing limb
Wing Limb D , Tip  wing hand's claw

Head 
Neck 00

Neck 01-06
Neck 07-11
Neck 12-16

Body 001
Body 002
Body 003

Tail 01-05
Tail 06-11
Tail 12-16
Tail 17-19
Tail Tip


# How I Designed This

it was hard to made. after i made set of wing after 4th try i was almost depleted any idea for body dispite take reference and ideas from other models

tail is quite short as it reach actual Limit of downsizing ball joint before unable to properly working as ball joints. if not those limit i would like to make tail twice time longer than now.

Tail tip and feet are easy to pop out.

Set of wing alone probably could use in my first articulated dragoness after configure ball and soket size of Wing 001, but i have no plan to doing that.