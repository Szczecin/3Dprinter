                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:388683
kossel800 k800 ver.hero delta 3dprinter deltabot arm by maximscy is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

k800打印机由kosselmini改变而来  
Remix from kossel mini  
ｋ８００はkosselmini廉価化のためデザインを変更する機種です  
.  
中文说明：   
 2014年3月26日我在百度贴吧上发表《800元组装一台3D打印机全教程流程》http://tieba.baidu.com/p/2944800373：　教大家如何通过淘宝上采购零件，自己组装一台低成本reprap开源kossel delta并联臂架构3d打印机，结果反响很高，在经过多个月的酝酿和大家的支持鼓励下，一致决定推出代号为“kossel800”开源diy3d打印机套件，此套件缩减了kossel原设计中的几个大成本大头从而使成本骤降，但是功能无减.  
玩家可以按照附带的详细安装说明教程，完全靠自己组装出一台性价比超高的delta 3D打印机。  
.  
Instructions:  
I posted “How to make a Kossel delta 3D printer with 800 RMBYuan” on Baidu Tieba, one of the largest Chinese online communities, on 03/26/2014 ( http://tieba.baidu.com/p/2944800373). In this post, I proposed a solution to build a Kossel 3D printer at a cost of 800 RMB Yuan (about US $130.00 ). The significant cost cutting is achieved by simplifying and optimizing the key parts in original Kossel design, without compromising the performance. The post attracted thousands of enthusiastic replies. After months of preparation, we decided to release low cost Kossel 3D printer kits named “Kossel800”with a detailed assembly guide. It is available for a price of 1000 Chinese Yuan (about US $160.00) on a Chinese online store.  
.  
k800３Ｄプリンター紹介：  
私は２０１４年３月中国一百度掲示板に”８００元（約１万４千円）で３ｄプリンターを作る方法”http://tieba.baidu.com/p/2944800373　を投稿し中国のDIY界に大きな注目を得た。みんなのおかけでそれからの２０１４年７月DREAMOREクラウドファンヂングで大きな成功を得た。８００元のためプリンターをK８００に命じ、あれから中国世界工場の優れ点におかけ質量よく安いｋ８００３ｄプリンターを開発進めていく世界へ輸出しているのは今の仕事。  
.  
k800的主要更改内容：  
由kosselmini的11mm大比例齿轮送丝轮-》k800的6mm小比例送丝轮  
why:make the parts cheaper  
由kosselmini的直线滑轨-》k800的滑车  
why:make the parts cheaper  
由kosselmini的万向节-》k800的强磁并联臂  
why:Easy to maintenance the hotend and fans and easy to change the effector for multipurpose.  
由kosselmini的巨型底座框架零件-》k800的通用框架零件  
why:Easy to print more frames.Easy to dublicator the printer more by your self  

maximscy, Shanghai, China  
translate by UNO & google  &春泥蛋炒饭  




///////////////////////////////////////////////////////////////////////////////////////////////////////////  
20150601  
///////////////////////////////////////////////////////////////////////////////////////////////////////////   


k800 accessories配件：  
Kossel mini (K800) LCD surpport LCD支架：√√√  
http://www.thingiverse.com/thing:437587  
Kossel 800 gadgets LCD支架2：  
http://www.thingiverse.com/thing:465962  
optic axis for Kossel k800光轴支架：  
http://www.thingiverse.com/thing:533751  
Kossel K800 stabilization滑车固定器：  
http://www.thingiverse.com/thing:655312  
Filament spool roller耗材卷动器：  
http://www.thingiverse.com/thing:696164  
Circular fan duct for Kossel 800环形风扇： √√√√√   
http://www.thingiverse.com/thing:455865  
Kossel mini pane插座l面板：  
http://www.thingiverse.com/thing:451719  
kossel K800 20X20 Strengthen the frame支架固定装置：  
http://www.thingiverse.com/thing:524927  
Three pointed Glass cramps and Positioning pins玻璃固定夹：  
http://www.thingiverse.com/thing:572064  
kossel effector打印件风扇支架：  
http://www.thingiverse.com/thing:747286  
RAMPS 1.4 Fan Mount, 40mm, parametrizable ramps风扇支架  √√√  
http://www.thingiverse.com/thing:145946  


///////////////////////////////////////////////////////////////////////////////////////////////////////////  



offical site:  
http://www.k800we.com  

chinese assembly instructions:  
http://www.dwz.cn/k800instructions  

about k800‘s CrowdFunding in 2014:  
http://www.dreamore.com/projects/14147.html  

ebay:  
http://www.ebay.com/itm/kossel-3D-printer-delta-Rostock-Reprap-Self-assembly-DIY-full-kit-/201336377829?pt=LH_DefaultDomain_0&hash=item2ee09551e5  

ali shop:  
http://www.aliexpress.com/item/2015-k800-Newest-Self-assembly-kossel-printer-k800-3D-printer-delta-printer-Reprap/32282584168.html?spm=0.0.0.0.v2QALy  

taobao:  
flowersox.taobao.com